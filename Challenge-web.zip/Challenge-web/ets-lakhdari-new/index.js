let navbar = document.querySelector('.header .navbar');
let contactinfo = document.querySelector('.contact-info');



document.querySelector('#menubtn').onclick =() => {
    navbar.classList.toggle('active');
    contactinfo.classList.remove('active');
}



window.onscroll= ()=>{
    navbar.classList.remove('active');
    contactinfo.classList.remove('active');
}

document.querySelector('#contactbtn').onclick= () =>{
    contactinfo.classList.add('active');
    navbar.classList.remove('active');
    
}
   



document.querySelector('#close-contact-info').onclick= () =>{
    contactinfo.classList.remove('active');
    navbar.classList.remove('active');
    
}


const imageContainer = document.getElementById("imageContainer");
const images = document.querySelectorAll(".scrollingImage");

// Clone the images and append them to the container
images.forEach((image) => {
  const clone = image.cloneNode(true);
  imageContainer.appendChild(clone);
});